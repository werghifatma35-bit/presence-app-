# Guide de déploiement (pour le service informatique) — environ 10 minutes

Application : feuille de présence aux réunions (participants : e-mail + code ; administrateurs : lien personnel).

## Ce qu'il faut
- Accès au projet Google Cloud de Clinisys (celui de Dot Collector) avec le rôle Cloud Run Admin + Storage Admin.
- Un compte SMTP pour envoyer les codes par e-mail (hôte, port, utilisateur, mot de passe, adresse d'expédition, ex. presence@csys.com.tn).

## Étapes (terminal avec gcloud installé, dans le dossier `presence-app`)
1. `gcloud auth login`
2. `gcloud config set project NOM_DU_PROJET`
3. `gsutil mb -l europe-west1 gs://presence-clinisys-data`
4. Déploiement (remplacer les valeurs SMTP) :

```
gcloud run deploy presence-clinisys --source . --region europe-west1 \
  --allow-unauthenticated --max-instances=1 \
  --set-env-vars GCS_BUCKET=presence-clinisys-data,SMTP_HOST=...,SMTP_PORT=587,SMTP_USER=...,SMTP_PASS=...,SMTP_FROM=presence@csys.com.tn
```
5. Donner au compte de service de Cloud Run (indiqué dans la console, Cloud Run > service > Sécurité) le rôle « Storage Object Admin » sur le bucket `presence-clinisys-data`.
6. Noter l'URL affichée (lien à partager aux participants).
7. Console > Cloud Run > presence-clinisys > Journaux : relever les lignes `[ADMIN] Nom : /a/...`. Le lien d'un administrateur = URL + ce chemin. À envoyer uniquement à la personne concernée.
8. Test : ouvrir `URL/healthz` (doit afficher « ok »), ouvrir l'URL, demander un code avec une adresse @csys.com.tn.

## Remarques
- `--max-instances=1` est nécessaire (les données sont gérées par une seule instance).
- Les participants et administrateurs sont dans `seed.json` (106 comptes) et modifiables ensuite dans l'application.
