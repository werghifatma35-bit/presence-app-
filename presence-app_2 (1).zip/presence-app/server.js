'use strict';
/**
 * Présence Clinisys — serveur
 * - Participants : ouvrent le lien, saisissent leur e-mail Clinisys, reçoivent un code par e-mail, puis signent.
 * - Administrateurs (Owner / Administrateur) : accès direct, sans e-mail ni code, via leur lien personnel /a/<jeton>.
 * Stockage : dossier local (par défaut) ou Google Cloud Storage (variable GCS_BUCKET).
 */
const express = require('express');
const crypto = require('crypto');
const fs = require('fs/promises');
const path = require('path');

const PORT = +process.env.PORT || 8080;
const STORE_DIR = process.env.STORE_DIR || path.join(__dirname, 'data');
const DEV_SHOW_CODE = process.env.DEV_SHOW_CODE === '1'; // tests uniquement
const ADMIN_ROLES = ['Owner', 'Administrateur'];
const ROLES = ['Owner', 'Administrateur', 'Manager', 'Collaborateur'];
const MAX_PDF = 2.5 * 1024 * 1024;

/* ---------- Stockage ---------- */
class FileStore {
  constructor(dir) { this.dir = dir; }
  async get(k) { try { return await fs.readFile(path.join(this.dir, k)); } catch { return null; } }
  async put(k, buf) {
    const f = path.join(this.dir, k);
    await fs.mkdir(path.dirname(f), { recursive: true });
    const tmp = f + '.tmp';
    await fs.writeFile(tmp, buf);
    await fs.rename(tmp, f);
  }
  async del(k) { try { await fs.unlink(path.join(this.dir, k)); } catch { /* absent */ } }
}
class GcsStore {
  constructor(bucket) { const { Storage } = require('@google-cloud/storage'); this.b = new Storage().bucket(bucket); }
  async get(k) { const f = this.b.file(k); const [ex] = await f.exists(); if (!ex) return null; const [buf] = await f.download(); return buf; }
  async put(k, buf) { await this.b.file(k).save(buf, { resumable: false }); }
  async del(k) { await this.b.file(k).delete({ ignoreNotFound: true }); }
}
const store = process.env.GCS_BUCKET ? new GcsStore(process.env.GCS_BUCKET) : new FileStore(STORE_DIR);

/* ---------- État en mémoire ---------- */
let state = { rev: 1, users: [], meetings: [] };
let SECRET = '';
let writeChain = Promise.resolve();
function persist() {
  const data = Buffer.from(JSON.stringify(state));
  writeChain = writeChain.then(() => store.put('state.json', data)).catch(e => console.error('persist error', e));
  return writeChain;
}
function bump() { state.rev++; return persist(); }

async function init() {
  const s = await store.get('secret.txt');
  if (s) SECRET = s.toString().trim();
  else { SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'); await store.put('secret.txt', Buffer.from(SECRET)); }
  const raw = await store.get('state.json');
  if (raw) state = JSON.parse(raw.toString());
  else { state.users = JSON.parse(await fs.readFile(path.join(__dirname, 'seed.json'), 'utf8')).users; await persist(); }
}

/* ---------- Utilitaires ---------- */
const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim().replace(/\s+/g, ' ');
const nameKey = s => norm(s).split(' ').sort().join(' ');
const okMail = e => /^[^\s@]+@(csys|clinisys)\.com\.tn$/i.test(e || '');
const str = (v, max) => String(v == null ? '' : v).slice(0, max);
const hmac = d => crypto.createHmac('sha256', SECRET).update(d).digest('hex');
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const isAdminUser = u => !!u && ADMIN_ROLES.includes(u.role);

const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return true; }
  arr.push(now); hits.set(key, arr); return false;
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.some(t => now - t < 3600e3)) hits.delete(k); }, 600e3).unref();

function cookies(req) {
  const o = {};
  (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return o;
}
function makeSession(uid, kind, ttl) {
  const body = Buffer.from(JSON.stringify({ uid, exp: Date.now() + ttl })).toString('base64url');
  return body + '.' + hmac(kind + ':' + body);
}
function readCookieSession(req, name, kind) {
  const c = cookies(req)[name]; if (!c) return null;
  const [body, sig] = c.split('.');
  if (!body || !sig || !safeEq(sig, hmac(kind + ':' + body))) return null;
  try {
    const d = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (d.exp < Date.now()) return null;
    return state.users.find(x => x.id === d.uid) || null;
  } catch { return null; }
}
const readSession = req => { const u = readCookieSession(req, 'sid', 'sid'); return isAdminUser(u) ? u : null; };
const readPart = req => { const u = readCookieSession(req, 'pid', 'pid'); return u && u.email ? u : null; };
const adminToken = u => `${u.id}-${hmac('adminlink:' + u.id).slice(0, 40)}`;
function requireAdmin(req, res, next) {
  const u = readSession(req);
  if (!u) return res.status(401).json({ error: 'Connexion administrateur requise.' });
  req.user = u; next();
}
function requireAjax(req, res, next) {
  if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'app') return res.status(400).json({ error: 'Requête invalide.' });
  next();
}

/* ---------- E-mail ---------- */
let transporter = null;
if (process.env.SMTP_HOST) {
  transporter = require('nodemailer').createTransport({
    host: process.env.SMTP_HOST, port: +process.env.SMTP_PORT || 587,
    secure: process.env.SMTP_SECURE === '1',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
}
async function sendCode(email, code) {
  if (!transporter) { console.log(`[AUTH] SMTP non configuré — code pour ${email} : ${code}`); return; }
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: 'Votre code de présence — Présence Clinisys',
    text: `Votre code pour marquer votre présence : ${code}\n\nIl est valable 10 minutes. Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.`,
  });
}

/* ---------- Validation ---------- */
function cleanUsers(list) {
  if (!Array.isArray(list) || list.length > 1000) throw new Error('Liste invalide.');
  const seen = new Set(); const out = [];
  for (const u of list) {
    const id = +u.id; if (!Number.isInteger(id) || id <= 0 || seen.has(id)) throw new Error('Identifiant invalide.');
    seen.add(id);
    const role = ROLES.includes(u.role) ? u.role : 'Collaborateur';
    const email = str(u.email, 120).trim().toLowerCase();
    if (email && !okMail(email)) throw new Error('Adresse invalide : ' + email);
    out.push({ id, name: str(u.name, 100).trim(), email, role, manager: str(u.manager, 100), color: /^#[0-9a-f]{6}$/i.test(u.color) ? u.color : '#0369a1' });
  }
  if (!out.some(u => isAdminUser(u) && u.email)) throw new Error('Il faut au moins un administrateur avec une adresse e-mail.');
  return out;
}
const SIG_RE = /^data:image\/png;base64,[A-Za-z0-9+/=]+$/;
function cleanPart(p) {
  const sig = typeof p.sig === 'string' && p.sig.length <= 150000 && SIG_RE.test(p.sig) ? p.sig : '';
  return { id: p.id == null ? null : +p.id, name: str(p.name, 100), email: str(p.email, 120), sig, at: typeof p.at === 'string' ? str(p.at, 40) : new Date().toISOString() };
}
async function mergeMeeting(m) {
  const id = +m.id; if (!Number.isInteger(id) || id <= 0) throw new Error('Réunion invalide.');
  const old = state.meetings.find(x => x.id === id);
  const date = /^\d{4}-\d{2}-\d{2}$/.test(m.date) ? m.date : new Date().toISOString().slice(0, 10);
  const parts = old ? [...old.parts] : [];
  const keyOf = p => (p.id != null ? 'u' + p.id : 'n' + nameKey(p.name));
  const have = new Set(parts.map(keyOf));
  for (const raw of Array.isArray(m.parts) ? m.parts : []) { const p = cleanPart(raw); if (p.name && !have.has(keyOf(p))) { parts.push(p); have.add(keyOf(p)); } }
  let link = ''; const l = str(m.pvLink, 500).trim();
  if (l) { try { const u = new URL(l); if (/^https?:$/.test(u.protocol)) link = u.href; } catch { /* ignore */ } }
  let pvFile = old ? old.pvFile || null : null;
  if (m.pvFile === null || m.pvFile === undefined) { if (m.pvFile === null && pvFile) { await store.del(`pdf/${id}.pdf`); pvFile = null; } }
  else if (m.pvFile.data) {
    const mt = /^data:application\/pdf;base64,([A-Za-z0-9+/=]+)$/.exec(m.pvFile.data);
    if (!mt) throw new Error('PDF invalide.');
    const buf = Buffer.from(mt[1], 'base64');
    if (buf.length > MAX_PDF || buf.slice(0, 4).toString() !== '%PDF') throw new Error('PDF invalide ou trop volumineux (2,5 Mo max).');
    await store.put(`pdf/${id}.pdf`, buf);
    pvFile = { name: str(m.pvFile.name, 120) };
  }
  const merged = {
    id, name: str(m.name, 200).trim() || 'Réunion', date,
    anim: { id: m.anim && m.anim.id != null ? +m.anim.id : null, name: str(m.anim && m.anim.name, 100) },
    pvLink: link, pv: str(m.pv, 5000), pvFile,
    status: m.status === 'closed' ? 'closed' : 'open', parts,
  };
  if (old) Object.assign(old, merged); else state.meetings.push(merged);
}

/* ---------- Application ---------- */
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY' });
  next();
});
app.get('/healthz', (req, res) => res.send('ok'));

/* --- Participants (sans connexion) --- */
const pub = express.Router();
pub.use(express.json({ limit: '300kb' }), requireAjax);
const viewToken = (mid, uid) => `${uid}-${hmac(`pv:${mid}:${uid}`).slice(0, 32)}`;
function checkViewToken(mid, t) {
  const [uid, h] = String(t || '').split('-');
  return uid && h && safeEq(h, hmac(`pv:${mid}:${uid}`).slice(0, 32)) ? +uid : null;
}
const codes = new Map();
pub.post('/auth/request', async (req, res) => {
  const email = str(req.body.email, 120).trim().toLowerCase();
  if (!okMail(email)) return res.status(400).json({ error: 'Adresse @csys.com.tn ou @clinisys.com.tn requise.' });
  if (limited('ar:ip:' + req.ip, 20, 600e3) || limited('ar:' + email, 3, 600e3)) return res.status(429).json({ error: 'Trop de demandes. Réessayez dans quelques minutes.' });
  const u = state.users.find(x => x.email === email);
  const out = { ok: true };
  if (u) {
    const code = String(crypto.randomInt(100000, 1000000));
    codes.set(email, { hash: hmac('code:' + email + ':' + code), exp: Date.now() + 10 * 60e3, tries: 0 });
    try { await sendCode(email, code); } catch (e) { console.error('mail error', e.message); }
    if (DEV_SHOW_CODE) out.devCode = code;
  }
  res.json(out); // même réponse que l'adresse existe ou non
});
pub.post('/auth/verify', (req, res) => {
  const email = str(req.body.email, 120).trim().toLowerCase(), code = str(req.body.code, 10).trim();
  if (limited('av:ip:' + req.ip, 30, 600e3)) return res.status(429).json({ error: 'Trop de tentatives.' });
  const c = codes.get(email), u = state.users.find(x => x.email === email);
  if (!c || !u || c.exp < Date.now()) return res.status(400).json({ error: 'Code expiré ou invalide. Demandez-en un nouveau.' });
  if (++c.tries > 5) { codes.delete(email); return res.status(400).json({ error: 'Trop de tentatives. Demandez un nouveau code.' }); }
  if (!safeEq(c.hash, hmac('code:' + email + ':' + code))) return res.status(400).json({ error: 'Code incorrect.' });
  codes.delete(email);
  res.cookie('pid', makeSession(u.id, 'pid', 12 * 3600e3), { httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: 12 * 3600e3, path: '/' });
  res.json({ user: { id: u.id, name: u.name } });
});
pub.get('/me', (req, res) => { const u = readPart(req); res.json({ user: u ? { id: u.id, name: u.name } : null }); });
pub.post('/auth/logout', (req, res) => { res.clearCookie('pid', { path: '/' }); res.json({ ok: true }); });
const needPart = (req, res, next) => { const u = readPart(req); if (!u) return res.status(401).json({ error: 'Connexion requise.' }); req.part = u; next(); };

pub.get('/meetings', needPart, (req, res) => {
  res.json(state.meetings.filter(m => m.status === 'open').sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id)
    .map(m => ({ id: m.id, name: m.name, date: m.date, presenter: m.anim.name })));
});
pub.post('/meetings/:id/sign', needPart, (req, res) => {
  if (limited('sign:' + req.ip, 40, 600e3)) return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans quelques minutes.' });
  const m = state.meetings.find(x => x.id === +req.params.id);
  if (!m || m.status !== 'open') return res.status(409).json({ error: "Cette réunion n'est plus ouverte." });
  const name = str(req.body.name, 100).trim().replace(/\s+/g, ' ');
  if (name.length < 3 || !name.includes(' ')) return res.status(400).json({ error: 'Écrivez votre nom et prénom.' });
  const sig = req.body.sig;
  if (typeof sig !== 'string' || sig.length > 150000 || !SIG_RE.test(sig)) return res.status(400).json({ error: 'Signature invalide.' });
  const u = req.part;
  if (nameKey(u.name) !== nameKey(name)) return res.status(422).json({ error: "Le nom ne correspond pas à l'adresse e-mail vérifiée. Écrivez votre nom et prénom comme dans l'annuaire Clinisys." });
  if (m.parts.some(p => p.id === u.id)) return res.status(409).json({ error: 'Votre présence est déjà enregistrée.' });
  const part = { id: u.id, name: u.name, email: u.email, sig, at: new Date().toISOString() };
  m.parts.push(part); bump();
  res.json({ name: u.name, at: part.at, token: viewToken(m.id, u.id) });
});
pub.get('/meetings/:id/pv', (req, res) => {
  const m = state.meetings.find(x => x.id === +req.params.id);
  const uid = checkViewToken(req.params.id, req.query.t);
  if (!m || uid == null || !m.parts.some(p => p.id === uid)) return res.status(404).json({ error: 'Introuvable.' });
  res.json({ id: m.id, name: m.name, date: m.date, presenter: m.anim.name, status: m.status, pvLink: m.pvLink || '', pv: m.pv || '', pdfName: m.pvFile ? m.pvFile.name : '' });
});
pub.get('/meetings/:id/pdf', async (req, res) => {
  const m = state.meetings.find(x => x.id === +req.params.id);
  const uid = checkViewToken(req.params.id, req.query.t);
  if (!m || !m.pvFile || uid == null || !m.parts.some(p => p.id === uid)) return res.status(404).send('Introuvable');
  const buf = await store.get(`pdf/${m.id}.pdf`); if (!buf) return res.status(404).send('Introuvable');
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': 'inline; filename="pv.pdf"' }).send(buf);
});
app.use('/api/public', pub);

/* --- Administrateurs --- */
const api = express.Router();
api.use(express.json({ limit: '8mb' }), requireAjax);

api.get('/me', (req, res) => { const u = readSession(req); res.json({ user: u || null }); });

api.post('/auth/logout', (req, res) => { res.clearCookie('sid', { path: '/' }); res.json({ ok: true }); });

api.get('/state', requireAdmin, (req, res) => {
  if (+req.query.rev === state.rev) return res.json({ same: true, rev: state.rev });
  res.json({ rev: state.rev, users: state.users, meetings: state.meetings });
});
api.put('/users', requireAdmin, async (req, res) => {
  try { state.users = cleanUsers(req.body.users); } catch (e) { return res.status(400).json({ error: e.message }); }
  await bump();
  res.json({ rev: state.rev });
});
api.post('/meetings/sync', requireAdmin, async (req, res) => {
  try {
    for (const m of Array.isArray(req.body.upsert) ? req.body.upsert : []) await mergeMeeting(m);
    for (const id of Array.isArray(req.body.delete) ? req.body.delete : []) {
      const i = state.meetings.findIndex(x => x.id === +id);
      if (i >= 0) { state.meetings.splice(i, 1); await store.del(`pdf/${+id}.pdf`); }
    }
  } catch (e) { return res.status(400).json({ error: e.message }); }
  await bump();
  res.json({ rev: state.rev, users: state.users, meetings: state.meetings });
});
api.get('/meetings/:id/pdf', requireAdmin, async (req, res) => {
  const m = state.meetings.find(x => x.id === +req.params.id);
  const buf = m && m.pvFile ? await store.get(`pdf/${m.id}.pdf`) : null;
  if (!buf) return res.status(404).send('Introuvable');
  res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': 'inline; filename="pv.pdf"' }).send(buf);
});
app.use('/api', api);
app.get('/a/:tok', (req, res) => {
  if (limited('al:' + req.ip, 30, 600e3)) return res.status(429).send('Trop de tentatives.');
  const uid = +String(req.params.tok).split('-')[0];
  const u = state.users.find(x => x.id === uid);
  if (!isAdminUser(u) || !safeEq(req.params.tok, adminToken(u))) return res.status(404).send('Lien invalide.');
  res.cookie('sid', makeSession(u.id, 'sid', 30 * 24 * 3600e3), { httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: 30 * 24 * 3600e3, path: '/' });
  res.set('Cache-Control', 'no-store').redirect('/');
});
app.use('/api', (req, res) => res.status(404).json({ error: 'Introuvable.' }));

app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, index: 'index.html' }));

init().then(() => app.listen(PORT, () => { for (const u of state.users.filter(isAdminUser)) console.log(`[ADMIN] ${u.name} : /a/${adminToken(u)}`); console.log(`Présence Clinisys sur le port ${PORT} (stockage : ${process.env.GCS_BUCKET ? 'GCS ' + process.env.GCS_BUCKET : STORE_DIR})`); }))
  .catch(e => { console.error(e); process.exit(1); });
