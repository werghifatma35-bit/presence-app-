# Présence Clinisys — application web

Application de feuilles de présence accessible par un lien HTTP(S).

- **Participants** : ouvrent le lien, saisissent leur e-mail @csys.com.tn / @clinisys.com.tn, reçoivent un code par e-mail, puis écrivent nom et prénom, signent et voient le PV.
- **Administrateurs** (Owner / Administrateur) : accès direct, sans e-mail ni code, avec leur **lien personnel** `https://<url>/a/<jeton>`. Ouvrir ce lien = être connecté (30 jours sur cet appareil). Les liens sont affichés dans les logs au démarrage (`[ADMIN] Nom : /a/...`). Ils sont secrets : ne les partager qu'avec la personne concernée.

## Lancer en local
    npm install
    PORT=8080 DEV_SHOW_CODE=1 node server.js     # DEV_SHOW_CODE : tests uniquement
Ouvrir http://localhost:8080/

## Déployer sur Google Cloud Run
    gsutil mb -l europe-west1 gs://presence-clinisys-data
    gcloud run deploy presence-clinisys --source . --region europe-west1 \
      --allow-unauthenticated --max-instances=1 \
      --set-env-vars GCS_BUCKET=presence-clinisys-data,SMTP_HOST=...,SMTP_PORT=587,SMTP_USER=...,SMTP_PASS=...,SMTP_FROM=...
Donner au compte de service Cloud Run le rôle « Storage Object Admin » sur le bucket.
Le lien à partager est l'URL fournie ; `?m=<id>` ouvre directement une réunion.

## Variables
PORT, STORE_DIR, GCS_BUCKET, SMTP_HOST/PORT/SECURE/USER/PASS/FROM, SESSION_SECRET (optionnel).
SMTP_* est obligatoire pour que les participants reçoivent leur code par e-mail ; sans SMTP, le code n'est écrit que dans les logs.
Santé : /healthz
